#!/bin/bash
# Copyright 2018 VMware, Inc. All Rights Reserved.
#

usage='pks::nsx::client method api [payload]'

# NSX client that talks to the manager
pks::nsx::client() {
  local method=${1:?$usage}
  local api=${2:+'api/v1/'$2}
  : ${api:?$usage}
  local payload=${3:+-d $3}
  local proxy=${HTTP_PROXY:+--proxy ${HTTP_PROXY}}

  case $method in
  "get"*)
    curl -s ${proxy} -k -u ${NSX_MANAGER_USERNAME}:${NSX_MANAGER_PASSWORD} -X GET https://${NSX_MANAGER_IP}/$api
    ;;
  "post"*)
    curl -H "Content-Type: application/json" -s ${proxy} -k -u ${NSX_MANAGER_USERNAME}:${NSX_MANAGER_PASSWORD} -X POST "${payload}" https://${NSX_MANAGER_IP}/$api
    ;;
  "put"*)
    curl -H "Content-Type: application/json" -s ${proxy} -k -u ${NSX_MANAGER_USERNAME}:${NSX_MANAGER_PASSWORD} -X PUT "${payload}" https://${NSX_MANAGER_IP}/$api
    ;;
  "delete"*)
    curl -H "Content-Type: application/json" -s ${proxy} -k -u ${NSX_MANAGER_USERNAME}:${NSX_MANAGER_PASSWORD} -X DELETE https://${NSX_MANAGER_IP}/$api
    ;;
  *)
    echo "Unrecognized method: ${method}"
    ;;
  esac
}

env_check() {
  : ${NSX_MANAGER_USERNAME:?}
  : ${NSX_MANAGER_PASSWORD:?}
  : ${NSX_MANAGER_IP:?}
}

print_error() {
  printf "%s\n" "$*" >&2;
}

quiet_pushd() {
  pushd $1 > /dev/null
}

quiet_popd() {
  popd $1 > /dev/null
}
