#!/bin/bash
# Copyright 2018 VMware, Inc. All Rights Reserved.
#

set -e
set -o pipefail

SCRIPT_DIR="$(dirname "${BASH_SOURCE}")"
cd "${SCRIPT_DIR}"
source utils.sh

NSX_T_PKS_TAG_KEY_CLUSTER="pks/cluster"
NSX_T_NCP_TAG_KEY_EXTERNAL="ncp/external"
NSX_T_NCP_TAG_VALUE_TRUE="true"
NSX_T_NCP_TAG_KEY_SHARED_RESOURCE="ncp/shared_resource"

usage() {
  echo "bash ${BASH_SOURCE} [category] [method] [parameters...]"
  echo "ipam"
  echo "  allocate"
  echo "  release [IP_ADDRESS]"
  echo "nat"
  echo "  create-rule [CLUSTER_UUID] [MASTER_IP] [FLOATING_IP]"
  echo "  delete-rule [CLUSTER_UUID]"
  echo "cleanup [CLUSTER_UUID] [DRY_RUN]"
}

nsx::check_response_for_error() {
  local response=${1}
  local error_code=$(echo $response | jq .error_code | tr -d '""')
  local user_error_message=${2}
  local exit_on_error=${3:-true}

  if [ "$error_code" != "null" ]; then
    local error_message=$(echo $response | jq .error_message | tr -d '""')
    if [ "$exit_on_error" = true ] ; then
      print_error "ERROR: $user_error_message due to error code: $error_code, error message: $error_message"
      exit 1
    else
      return 1
    fi
  else
    return 0
  fi
}

pks::nsx::get_floating_ip_pool_id() {
  if [ -n "$FLOATING_IP_POOL_ID" ]; then
    echo "$FLOATING_IP_POOL_ID"
  elif [ -n "${NSX_FLOATING_IP_POOL_ID}" ]; then
    echo "${NSX_FLOATING_IP_POOL_ID}"
  else
    local response=$(nsx::search_resource_by_tag "IpPool" "$NSX_T_NCP_TAG_KEY_EXTERNAL" "$NSX_T_NCP_TAG_VALUE_TRUE")
    local count=$(echo "$response" | jq .result_count)
    if [ "$count" -gt 1 ]; then
      echo "Multiple floating IP pools matching tag { "$NSX_T_NCP_TAG_KEY_EXTERNAL" : "$NSX_T_NCP_TAG_VALUE_TRUE" } found. Please provide a single floating IP pool ID"
      exit 1
    fi
    echo "$response" | jq -r .results[0].id
  fi
}

pks::nsx::check_duplicate_floating_ip() {
  local t0router_id=${1}
  local fip=${2}
  local cluster_uuid=${3}
  local response=$(nsx::search_by_query "resource_type%3ANatRule%20AND%20logical_router_id%3A%22${t0router_id}%22%20AND%20action%3A%22DNAT%22%20AND%20match_destination_network%3A%22${fip}%22%20AND%20tags.scope%3A%22${NSX_T_PKS_TAG_KEY_CLUSTER}%22")
  local nat_rule_id=$(echo "$response" | jq -r '.results[0].id')
  local router_id=$(echo "$response" | jq -r '.results[0].logical_router_id')

  if [[ "$nat_rule_id" != null && ! -z "$nat_rule_id" ]]; then
    local nat_rule_cluster_tag=$(echo "$response" | jq -r ".results[0].tags[] | select(.scope==\"$NSX_T_PKS_TAG_KEY_CLUSTER\")")
    local nat_rule_cluster_uuid=$(echo "$nat_rule_cluster_tag" | jq -r '.tag')
    if [ "$nat_rule_cluster_uuid" != "$cluster_uuid" ]; then
      print_error "ERROR: PKS NSX-T FLOATING IP ${fip} cannot be given to K8S cluster ${cluster_uuid} due to it being allocated to different K8S cluster $nat_rule_cluster_uuid"
      exit 1
    fi
  fi
}

pks::nsx::check_if_floating_ip_allocated() {
  local fip=${1}
  local fip_id=$(pks::nsx::get_floating_ip_pool_id)
  if [ -z "$fip_id" ]; then
    print_error "Failed to find Floating IP Pool ID tagged with { $NSX_T_NCP_TAG_KEY_EXTERNAL : $NSX_T_NCP_TAG_VALUE_TRUE }"
    exit 1
  fi

  local response=$(pks::nsx::client get "pools/ip-pools/${fip_id}/allocations")
  nsx::check_response_for_error "$response" "Failed to find allocations from floating IP pool ${fip_id}"
  fip_allocated=$(echo "$response" | jq -r ".results[] | select(.allocation_id==\"${fip}\")")
  if [ -z "$fip_allocated" ]; then
    print_error "ERROR: Floating IP ${fip} is not allocated from floating IP pool ${fip_id}"
    exit 1
  fi
}

pks::nsx::allocate_floating_ip() {
    local fip_id=$(pks::nsx::get_floating_ip_pool_id)
    if [ -z "$fip_id" ]; then
      print_error "Failed to find Floating IP Pool ID tagged with { $NSX_T_NCP_TAG_KEY_EXTERNAL : $NSX_T_NCP_TAG_VALUE_TRUE }"
      exit 1
    fi

    local response=$(pks::nsx::client post "pools/ip-pools/${fip_id}?action=ALLOCATE" '{"allocation_id": null}')
    nsx::check_response_for_error "$response" "Failed to allocate floating IP from IP pool ${fip_id}"
    local allocated_ip=$(echo "$response" | jq -c -r '.allocation_id')
    echo "Allocated IP: ${allocated_ip}"
}

pks::nsx::release_floating_ip() {
    if [ ! ${#@} -eq 1 ]; then
      usage
      exit 1
    fi

    local allocated_ip=${1}
    local fip_id=$(pks::nsx::get_floating_ip_pool_id)
    if [ -z "$fip_id" ]; then
      print_error "Failed to find Floating IP Pool ID tagged with { $NSX_T_NCP_TAG_KEY_EXTERNAL : $NSX_T_NCP_TAG_VALUE_TRUE }"
      exit 1
    fi

    local response=$(pks::nsx::client post "pools/ip-pools/${fip_id}?action=RELEASE" "{\"allocation_id\": \"${allocated_ip}\"}")
    if [ -n "$response" ]; then
      nsx::check_response_for_error "$response" "Failed to release floating IP from IP pool ${fip_id}"
    fi
    echo "Released IP ${allocated_ip} back to IP Pool ${fip_id} successfully"
}

ipam() {
  if [ ${#@} -le 0 ]; then
    usage
    exit 1
  fi
  local method=${1}
  shift
  case ${method} in
  "allocate"*)
    pks::nsx::allocate_floating_ip "$@"
    ;;
  "release"*)
    pks::nsx::release_floating_ip "$@"
    ;;
  *)
    echo "Unrecognized method: ${method}"
    usage
    ;;
  esac
}

pks::nsx::get_t0_router_id() {
  if [ -n "$NSX_T0_ROUTER_ID" ]; then
    echo "$NSX_T0_ROUTER_ID"
  else
    local response=$(nsx::search_resource_by_tag "LogicalRouter" "$NSX_T_NCP_TAG_KEY_SHARED_RESOURCE" "$NSX_T_NCP_TAG_VALUE_TRUE")
    local count=$(echo "$response" | jq .result_count)
    if [ "$count" -gt 1 ]; then
      echo "Multiple routers matching tag { "$NSX_T_NCP_TAG_KEY_SHARED_RESOURCE" : "$NSX_T_NCP_TAG_VALUE_TRUE" } found. Please provide a single T0 Router ID"
    fi
    echo "$response" | jq -r .results[0].id
  fi
}

nsx::search_by_query() {
  local search_query=${1}
  local response=$(pks::nsx::client get "search?query=${search_query}")
  nsx::check_response_for_error "$response" "Error searching query ${search_query}"
  echo "$response" | jq -r .
}

nsx::search_resource_by_tag() {
  if [ ! ${#@} -eq 3 ]; then
    usage
    exit 1
  fi
  local resource_type=${1}
  local tag_key=${2}
  local tag_value=${3}

  local response=$(pks::nsx::client get "search?query=resource_type%3A${resource_type}%20AND%20tags.scope%3A%22${tag_key}%22%20AND%20tags.tag%3A%22${tag_value}%22")
  nsx::check_response_for_error "$response" "Failed to search resource ${resource_type} with tag { ${tag_key} : ${tag_value} }"
  echo "$response" | jq -r .
}

pks::nsx::create_nat_rule() {
  if [ ! ${#@} -eq 3 ]; then
    usage
    exit 1
  fi
  local cluster_uuid="${1}"
  pattern='^\{?[A-Z0-9a-z]{8}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{12}\}?$'
  if [[ "$cluster_uuid" =~ $pattern ]]; then
    # appending pks- before cluster_uuid to make it more consistent on nsx-manager backend
    cluster_uuid="pks-${1}"
  fi
  local master_ip=${2}
  local fip=${3}
  local t0router_id=$(pks::nsx::get_t0_router_id)

  if [ -z "$t0router_id" ]; then
    print_error "Failed to find T0 Router ID tagged with { $NSX_T_NCP_TAG_KEY_SHARED_RESOURCE : $NSX_T_NCP_TAG_VALUE_TRUE }"
    exit 1
  fi

  local tag_json="[ \
      { \
        \"scope\": \"${NSX_T_PKS_TAG_KEY_CLUSTER}\",
        \"tag\": \"${cluster_uuid}\"
      } \
    ]"
  local nat_rule_json="{ \
    \"action\": \"DNAT\", \
    \"match_destination_network\": \"${fip}\", \
    \"translated_network\": \"${master_ip}\", \
    \"tags\":${tag_json} \
    }"

  local nat_rule_response=$(nsx::search_resource_by_tag "NatRule" "${NSX_T_PKS_TAG_KEY_CLUSTER}" "${cluster_uuid}")
  local nat_rule_id=$(echo "$nat_rule_response" | jq -r .results[0].id)
  if [[ $nat_rule_id == null || -z "$nat_rule_id" ]]; then
    pks::nsx::check_if_floating_ip_allocated "${fip}"
    pks::nsx::check_duplicate_floating_ip "${t0router_id}" "${fip}" "${cluster_uuid}"
    local response=$(pks::nsx::client post "logical-routers/${t0router_id}/nat/rules" "${nat_rule_json}" | jq .)
    nsx::check_response_for_error "$response" "Failed to create NAT rule on T0 Router ${t0router_id} from ${fip} to ${master_ip}"
    nat_rule_id=$(echo "$response" | jq -r .id)
    echo "Created NAT rule ${nat_rule_id} on T0 Router ${t0router_id} from ${fip} to ${master_ip} successfully"
  else
    local translated_ip=$(echo "$nat_rule_response" | jq -r .results[0].translated_network)
    local target_ip=$(echo "$nat_rule_response" | jq -r .results[0].match_destination_network)
    if [[ "$translated_ip" != "${master_ip}" || "$target_ip" != "${fip}" ]]; then
      nat_rule_get_response=$(pks::nsx::client get "logical-routers/${t0router_id}/nat/rules/${nat_rule_id}")
      nat_rule_json=$(echo "$nat_rule_get_response" | jq -r ".translated_network = \"${master_ip}\"" | jq -r ".match_destination_network = \"${fip}\"" | jq -r ".tags = ${tag_json}")
      pks::nsx::check_if_floating_ip_allocated "${fip}"
      pks::nsx::check_duplicate_floating_ip "${t0router_id}" "${fip}" "${cluster_uuid}"
      local response=$(pks::nsx::client put "logical-routers/${t0router_id}/nat/rules/${nat_rule_id}" "${nat_rule_json}" | jq .)
      nsx::check_response_for_error "$response" "Failed to update NAT rule ${nat_rule_id} on T0 Router ${t0router_id} from ${fip} to ${master_ip}"
      echo "Updated NAT rule ${nat_rule_id} on T0 Router ${t0router_id} from ${fip} to ${master_ip} successfully"
    else
      echo "NAT rule ${nat_rule_id} on T0 Router ${t0router_id} from ${fip} to ${master_ip} is already created"
    fi
  fi
}

pks::nsx::delete_nat_rule() {
  if [ ! ${#@} -eq 1 ]; then
    usage
    exit 1
  fi
  local cluster_uuid="${1}"
  pattern='^\{?[A-Z0-9a-z]{8}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{12}\}?$'
  if [[ "$cluster_uuid" =~ $pattern ]]; then
    # appending pks- before cluster_uuid to make it more consistent on nsx-manager backend
    cluster_uuid="pks-${1}"
  fi
  local t0router_id=$(pks::nsx::get_t0_router_id)
  if [ -z "$t0router_id" ]; then
    print_error "Failed to find T0 Router ID tagged with { $NSX_T_NCP_TAG_KEY_SHARED_RESOURCE : $NSX_T_NCP_TAG_VALUE_TRUE }"
    exit 1
  fi

  local nat_rule_response=$(nsx::search_resource_by_tag "NatRule" "${NSX_T_PKS_TAG_KEY_CLUSTER}" "${cluster_uuid}")
  local nat_rule_id=$(echo "$nat_rule_response" | jq -r .results[0].id)

  if [[ "$nat_rule_id" != null && ! -z "$nat_rule_id" ]]; then
    local fip=$(echo "$nat_rule_response" | jq -r .results[0].match_destination_network)
    local master_ip=$(echo "$nat_rule_response" | jq -r .results[0].translated_network)
    local response=$(pks::nsx::client delete "logical-routers/${t0router_id}/nat/rules/${nat_rule_id}")
    if [ -n "$response" ]; then
      nsx::check_response_for_error "$response" "Failed to delete NAT rule ${nat_rule_id} on T0 Router ${t0router_id} from ${fip} to ${master_ip}"
    fi
    echo "Deleted NAT rule ${nat_rule_id} on T0 Router $t0router_id belonging to K8S cluster $cluster_uuid master node $master_ip and floating IP $fip successfully"
    pks::nsx::release_floating_ip ${fip}
  else
    print_error "Failed to find NAT rule on T0 Router $t0router_id belonging to K8S cluster $cluster_uuid"
    exit 1
  fi
}

nat() {
  if [ ${#@} -le 0 ]; then
    usage
    exit 1
  fi
  local method=${1}
  shift
  case ${method} in
  "create-rule"*)
    pks::nsx::create_nat_rule "$@"
    ;;
  "delete-rule"*)
    pks::nsx::delete_nat_rule "$@"
    ;;
  *)
    echo "Unrecognized method: ${method}"
    usage
    ;;
  esac
}

cleanup() {
  # a hack to fool vmware_nsxlib or it's going to find pbr.version from a local
  # file
  if [ ! ${#@} -eq 2 ]; then
    usage
    exit 1
  fi
  local cluster_uuid="${1}"
  pattern='^\{?[A-Z0-9a-z]{8}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{4}-[A-Z0-9a-z]{12}\}?$'
  if [[ "$cluster_uuid" =~ $pattern ]]; then
    # appending pks- before cluster_uuid to make it more consistent on nsx-manager backend
    cluster_uuid="pks-${1}"
  fi
  shift
  local dryrun=${1}
  shift
  case ${dryrun} in
  "false"*)
    quiet_pushd "${SCRIPT_DIR}"/nsx_cleanup
      ./nsx_cleanup --mgr-ip=$NSX_MANAGER_IP --username=$NSX_MANAGER_USERNAME --password=$NSX_MANAGER_PASSWORD -c ${cluster_uuid} -r=false
    quiet_popd
    ;;
  "False"*)
    quiet_pushd "${SCRIPT_DIR}"/nsx_cleanup
      ./nsx_cleanup --mgr-ip=$NSX_MANAGER_IP --username=$NSX_MANAGER_USERNAME --password=$NSX_MANAGER_PASSWORD -c ${cluster_uuid} -r=false
    quiet_popd
    ;;
  "true"*)
    quiet_pushd "${SCRIPT_DIR}"/nsx_cleanup
      ./nsx_cleanup --mgr-ip=$NSX_MANAGER_IP --username=$NSX_MANAGER_USERNAME --password=$NSX_MANAGER_PASSWORD -c ${cluster_uuid} -r=true
    quiet_popd
    ;;
  "True"*)
    quiet_pushd "${SCRIPT_DIR}"/nsx_cleanup
      ./nsx_cleanup --mgr-ip=$NSX_MANAGER_IP --username=$NSX_MANAGER_USERNAME --password=$NSX_MANAGER_PASSWORD -c ${cluster_uuid} -r=true
    quiet_popd
    ;;
  *)
    echo "Unrecognized dryrun option: ${dryrun}. Please use true or false."
    usage
    ;;
  esac
}

main() {
  env_check
  if [ ${#@} -le 0 ]; then
    usage
    exit 1
  fi
  local category=${1}
  shift
  case ${category} in
  "ipam"*)
    ipam "$@"
    ;;
  "nat"*)
    nat "$@"
    ;;
  "cleanup"*)
    cleanup "$@"
    ;;
  *)
    usage
    ;;
  esac
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  main "$@"
fi
